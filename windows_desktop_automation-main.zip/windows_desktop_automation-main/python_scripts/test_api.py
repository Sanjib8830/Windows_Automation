from flask import Flask, request, jsonify
import subprocess

app = Flask(__name__)

PLAYBOOK_DIR = "/home/sanjib/Ansible/Windows_Desktop_Automation/playbooks"
INVENTORY_FILE = f"{PLAYBOOK_DIR}/inventory.yml"
OTP_PLAYBOOK = f"{PLAYBOOK_DIR}/otp_validation.yml"
EXECUTION_PLAYBOOK = f"{PLAYBOOK_DIR}/maintainence.yml"  # replace with your actual execution playbook

@app.route("/run-playbook", methods=["POST"])
def run_playbook():
    data = request.get_json()
    otp = data.get("otp")

    if not otp:
        return jsonify({"error": "Missing OTP in request"}), 400

    try:
        # Step 1: Run OTP validation playbook
        otp_cmd = [
            "ansible-playbook",
            "-i", INVENTORY_FILE,
            OTP_PLAYBOOK,
            "-e", f"expected_otp={otp}",
            "-vvv"
        ]
        otp_result = subprocess.run(otp_cmd, capture_output=True, text=True)
        print(otp_result)
        print(otp_result.returncode)
        if otp_result.returncode != 0:
            # OTP validation failed
            return jsonify({
                "status": "failed",
                "step": "otp_validation",
                "stdout": otp_result.stdout,
                "stderr": otp_result.stderr
            }), 400

        # Step 2: OTP validation successful, run execution playbook
        exec_cmd = [
            "ansible-playbook",
            "-i", INVENTORY_FILE,
            EXECUTION_PLAYBOOK,
            "-vvv"
        ]
        exec_result = subprocess.run(exec_cmd, capture_output=True, text=True)

        return jsonify({
            "status": "success",
            "otp_validation": {
                "return_code": otp_result.returncode,
                "stdout": otp_result.stdout,
                "stderr": otp_result.stderr
            },
            "execution_playbook": {
                "return_code": exec_result.returncode,
                "stdout": exec_result.stdout,
                "stderr": exec_result.stderr
            }
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

