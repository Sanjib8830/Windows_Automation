from flask import Flask, jsonify, request
import subprocess
import os
import shutil
import random
import string
import datetime
import jwt
from jinja2 import Template

app = Flask(__name__)

# Config
PLAYBOOK_DIR = "/home/sanjib/Ansible/Windows_Desktop_Automation/playbooks"
INVENTORY_TEMPLATE_FILE = os.path.join(PLAYBOOK_DIR, "inventory.yml.j2")
OTP_PLAYBOOK = f"{PLAYBOOK_DIR}/otp_validation.yml"
SECRET_KEY = "super-secret-key"  # 🔒 store securely in real use

def random_suffix(length=6):
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))

def generate_inventory(target_ip, tmp_dir):
    """Generate dynamic inventory.yml from template."""
    with open(INVENTORY_TEMPLATE_FILE, "r") as f:
        template = Template(f.read())
    inventory_content = template.render(target_ip=target_ip)

    inventory_file_path = os.path.join(tmp_dir, "inventory.yml")
    with open(inventory_file_path, "w") as f:
        f.write(inventory_content)
    return inventory_file_path


@app.route("/run-playbook/<playbook_name>/<target_ip>", methods=["POST"])
def run_playbook(playbook_name, target_ip):
    """Single API: validate OTP, issue JWT, execute playbook."""
    data = request.get_json()
    otp = data.get("otp")
    token = request.headers.get("Authorization")
    
    # Step 1: Check for token (if present, validate it)
    if token:
        try:
            token_value = token.split(" ")[1]
            decoded = jwt.decode(token_value, SECRET_KEY, algorithms=["HS256"])
            if not decoded.get("otp_valid") or decoded.get("target_ip") != target_ip:
                return jsonify({"error": "OTP not validated for this target"}), 403
        except jwt.ExpiredSignatureError:
            return jsonify({"error": "Token expired"}), 403
        except jwt.InvalidTokenError:
            return jsonify({"error": "Invalid token"}), 403
        otp_validated = True
    else:
        otp_validated = False

    # Step 2: Require OTP if token is missing/invalid
    if not otp_validated:
        if not otp:
            return jsonify({"error": "Missing OTP"}), 400

    playbook_src_path = os.path.join(PLAYBOOK_DIR, playbook_name)
    if not os.path.exists(playbook_src_path):
        return jsonify({"status": "error", "message": f"Playbook {playbook_name} not found"}), 404

    try:
        # Create temp folder
        suffix = random_suffix()
        tmp_dir = f"/tmp/{playbook_name}_{suffix}"
        os.makedirs(tmp_dir, exist_ok=True)

        # Copy playbook
        tmp_playbook_path = os.path.join(tmp_dir, playbook_name)
        shutil.copy(playbook_src_path, tmp_playbook_path)

        # Generate dynamic inventory
        inventory_file_path = generate_inventory(target_ip, tmp_dir)

        # Step 3: OTP validation if not already validated by token
        if not otp_validated:
            otp_cmd = [
                "ansible-playbook",
                "-i", inventory_file_path,
                OTP_PLAYBOOK,
                "-e", f"expected_otp={otp}",
                "-vvv"
            ]
            otp_result = subprocess.run(otp_cmd, capture_output=True, text=True, cwd=tmp_dir)
            if otp_result.returncode != 0:
                return jsonify({
                    "status": "failed",
                    "step": "otp_validation",
                    "stdout": otp_result.stdout,
                    "stderr": otp_result.stderr
                }), 400

            # Issue JWT token valid for 10 minutes
            token_value = jwt.encode({
                "otp_valid": True,
                "target_ip": target_ip,
                "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=10)
            }, SECRET_KEY, algorithm="HS256")
        else:
            token_value = token.split(" ")[1]  # reuse existing valid token

        # Step 4: Run main execution playbook
        start_time = datetime.datetime.now()
        timestamp = start_time.strftime("%Y%m%d_%H%M%S")
        ansible_log_file = os.path.join(tmp_dir, f"ansible_log_{timestamp}.log")
        api_log_file = os.path.join(tmp_dir, f"api_log_{timestamp}.log")

        cmd = ["ansible-playbook", "-i", inventory_file_path, tmp_playbook_path]
        with open(ansible_log_file, "w") as logfile:
            result = subprocess.run(cmd, cwd=tmp_dir, stdout=logfile, stderr=subprocess.STDOUT, text=True)

        end_time = datetime.datetime.now()

        # Cleanup
        if os.path.exists(tmp_playbook_path):
            os.remove(tmp_playbook_path)
        if os.path.exists(inventory_file_path):
            os.remove(inventory_file_path)

        # API log
        api_log_entry = (
            f"[API LOG]\n"
            f"Playbook: {playbook_name}\n"
            f"Target IP: {target_ip}\n"
            f"OTP validated: YES\n"
            f"Start Time: {start_time}\n"
            f"End Time: {end_time}\n"
            f"Status: {'SUCCESS' if result.returncode == 0 else 'FAILED'}\n"
            "------------------------------------------------------------\n"
        )
        with open(api_log_file, "a") as api_log:
            api_log.write(api_log_entry)

        # Return response including token
        return jsonify({
            "status": "success" if result.returncode == 0 else "failed",
            "playbook": playbook_name,
            "target_ip": target_ip,
            "execution_folder": tmp_dir,
            "ansible_log": ansible_log_file,
            "api_log": api_log_file,
            "start_time": str(start_time),
            "end_time": str(end_time),
            "token": token_value
        }), (200 if result.returncode == 0 else 500)

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

