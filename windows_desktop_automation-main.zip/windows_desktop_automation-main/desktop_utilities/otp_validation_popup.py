#!/usr/bin/env python3
"""
otp_popup.py

Shows a small popup window with a single form field to enter an OTP.
When the user clicks Submit or presses Enter, the OTP is printed to stdout
and the program exits.

Usage:
    python otp_popup.py
    python otp_popup.py --title "Authorize" --mask

Notes:
- If stdout is not a TTY (e.g., when launched from some services), set the environment
  variable OTP_OUTPUT_FILE to a writable path (e.g., C:\Temp\otp.txt). The script will
  write the OTP there as a fallback.
- Exit code 0 on success (OTP printed), 1 when window closed/cancelled.
"""
import argparse
import os
import sys
import tkinter as tk
from tkinter import ttk

def write_output(otp: str):
    """Write OTP to stdout and optionally to OTP_OUTPUT_FILE env path as fallback."""
    try:
        # Try stdout first
        print(otp, flush=True)
    except Exception:
        pass

    out_path = os.environ.get("OTP_OUTPUT_FILE")
    if out_path:
        try:
            with open(out_path, "w", encoding="utf-8") as f:
                f.write(otp)
        except Exception as e:
            # Best effort only; don't crash the GUI on write failure
            # But log to stderr so caller can inspect (if available)
            print(f"[otp_popup] failed to write OTP to {out_path}: {e}", file=sys.stderr)

def main():
    parser = argparse.ArgumentParser(prog="otp_popup.py", description="Simple OTP entry popup.")
    parser.add_argument("--title", "-t", default="Enter OTP", help="Window title")
    parser.add_argument("--prompt", "-p", default="Please enter the OTP:", help="Prompt text")
    parser.add_argument("--mask", action="store_true", help="Mask the OTP input (show • instead of digits)")
    args = parser.parse_args()

    root = tk.Tk()
    root.title(args.title)
    root.resizable(False, False)

    # Keep window small and centered
    frm = ttk.Frame(root, padding="12 12 12 12")
    frm.grid(column=0, row=0, sticky=(tk.N, tk.W, tk.E, tk.S))

    # Prompt
    prompt_lbl = ttk.Label(frm, text=args.prompt)
    prompt_lbl.grid(column=0, row=0, columnspan=2, sticky=tk.W, pady=(0, 8))

    # OTP entry
    var = tk.StringVar()
    entry = ttk.Entry(frm, width=30, textvariable=var)
    if args.mask:
        entry.config(show="•")  # bullet char
    entry.grid(column=0, row=1, columnspan=2, sticky=(tk.W, tk.E))
    entry.focus_set()

    # Buttons
    def submit_and_close(event=None):
        otp = var.get().strip()
        if otp == "":
            # Optional: do a shake or flash to indicate empty - keep it simple
            root.bell()
            return
        # Destroy window first (so GUI disappears quickly)
        root.destroy()
        # Write OTP to stdout (and fallback file)
        write_output(otp)
        # Exit explicitly
        sys.exit(0)

    def on_cancel():
        root.destroy()
        # Signal cancelled via non-zero exit code
        sys.exit(1)

    submit_btn = ttk.Button(frm, text="Submit", command=submit_and_close)
    submit_btn.grid(column=0, row=2, sticky=(tk.W), pady=(10, 0))
    cancel_btn = ttk.Button(frm, text="Cancel", command=on_cancel)
    cancel_btn.grid(column=1, row=2, sticky=(tk.E), pady=(10, 0))

    # Bind Enter to submit, Escape to cancel
    root.bind("<Return>", submit_and_close)
    root.bind("<KP_Enter>", submit_and_close)  # keypad Enter
    root.bind("<Escape>", lambda e: on_cancel())

    # Minimal styling: add padding to children
    for child in frm.winfo_children():
        child.grid_configure(padx=6, pady=4)

    # Center the window on screen
    root.update_idletasks()
    w = root.winfo_width()
    h = root.winfo_height()
    ws = root.winfo_screenwidth()
    hs = root.winfo_screenheight()
    x = (ws // 2) - (w // 2)
    y = (hs // 2) - (h // 2)
    root.geometry(f"{w}x{h}+{x}+{y}")

    try:
        root.mainloop()
    except SystemExit:
        # allow sys.exit from callbacks to pass through
        raise
    except Exception as e:
        print(f"[otp_popup] GUI loop crashed: {e}", file=sys.stderr)
        sys.exit(2)

    # If window closed without submitting (shouldn't reach here due to sys.exit in callbacks)
    sys.exit(1)

if __name__ == "__main__":
    main()
