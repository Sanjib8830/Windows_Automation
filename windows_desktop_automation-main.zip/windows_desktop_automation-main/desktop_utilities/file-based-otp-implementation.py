# execution_api.py - Modified for File-Based OTP System
from flask import Flask, jsonify, request
import subprocess
import os
import shutil
import random
import string
import datetime
from jinja2 import Template
import threading
import time

app = Flask(__name__)

# Configuration
PLAYBOOK_DIR = "/home/sanjib/Ansible/Windows_Desktop_Automation/playbooks"
INVENTORY_TEMPLATE_FILE = os.path.join(PLAYBOOK_DIR, "inventory.yml.j2")

def random_suffix(length=6):
    """Generate random alphanumeric string."""
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))

def generate_otp(length=6):
    """Generate random OTP"""
    return ''.join(random.choices(string.digits, k=length))

def winrm_connection(inventory_file_path, host="all"):
    return ["ansible", "-i", inventory_file_path, host, "-m", "win_ping"]

def create_otp_verification_playbook(tmp_dir, target_ip, expected_otp, main_playbook_path):
    """Create a playbook that verifies OTP before executing main playbook"""
    
    otp_playbook_content = f"""---
- name: OTP Verification and Playbook Execution
  hosts: all
  gather_facts: no
  vars:
    expected_otp: "{expected_otp}"
    otp_file_path: "C:\\\\Users\\\\%USERNAME%\\\\Desktop\\\\otp.txt"
    main_playbook: "{main_playbook_path}"
  
  tasks:
    - name: Check if OTP file exists on desktop
      win_stat:
        path: "{{{{ otp_file_path }}}}"
      register: otp_file_stat
      
    - name: Fail if OTP file doesn't exist
      fail:
        msg: "OTP file not found at {{{{ otp_file_path }}}}. Please create the file with your OTP."
      when: not otp_file_stat.stat.exists
      
    - name: Read OTP from desktop file
      win_shell: Get-Content "{{{{ otp_file_path }}}}" -Raw
      register: desktop_otp_raw
      
    - name: Clean OTP (remove whitespace/newlines)
      set_fact:
        desktop_otp: "{{{{ desktop_otp_raw.stdout | trim }}}}"
        
    - name: Display OTP comparison for debugging
      debug:
        msg: 
          - "Expected OTP: {{{{ expected_otp }}}}"
          - "Desktop OTP: '{{{{ desktop_otp }}}}'"
          - "Match: {{{{ desktop_otp == expected_otp }}}}"
          
    - name: Verify OTP matches
      fail:
        msg: "OTP verification failed! Expected: {{{{ expected_otp }}}}, Got: {{{{ desktop_otp }}}}"
      when: desktop_otp != expected_otp
      
    - name: OTP verification successful
      debug:
        msg: "✅ OTP verified successfully! Proceeding with main playbook execution..."
        
    - name: Delete OTP file after successful verification
      win_file:
        path: "{{{{ otp_file_path }}}}"
        state: absent
        
    # Include your actual playbook tasks here
    - name: Execute main playbook tasks
      include_tasks: "{{{{ main_playbook }}}}"
      
    - name: Execution completed successfully
      debug:
        msg: "🎉 Playbook execution completed successfully!"
"""
    
    otp_playbook_path = os.path.join(tmp_dir, "otp_verification.yml")
    with open(otp_playbook_path, "w") as f:
        f.write(otp_playbook_content)
    
    return otp_playbook_path

def playbook_background_task_with_otp(playbook_name, target_ip, expected_otp, result_dict):
    """Execute playbook with OTP verification"""
    playbook_src_path = os.path.join(PLAYBOOK_DIR, playbook_name)

    # Check if playbook exists
    if not os.path.exists(playbook_src_path):
        result_dict['response'] = {
            "status": "error",
            "message": f"Playbook {{playbook_name}} not found in {{PLAYBOOK_DIR}}"
        }
        result_dict['status_code'] = 404
        return

    try:
        # Create temporary folder
        suffix = random_suffix()
        tmp_dir = f"/tmp/{{playbook_name}}_{{suffix}}_otp"
        os.makedirs(tmp_dir, exist_ok=True)

        # Copy main playbook to temp folder
        tmp_main_playbook_path = os.path.join(tmp_dir, playbook_name)
        shutil.copy(playbook_src_path, tmp_main_playbook_path)

        # Create OTP verification playbook
        otp_playbook_path = create_otp_verification_playbook(
            tmp_dir, target_ip, expected_otp, tmp_main_playbook_path
        )

        # Generate inventory.yml from Jinja2 template
        with open(INVENTORY_TEMPLATE_FILE, "r") as f:
            template = Template(f.read())
        inventory_content = template.render(target_ip=target_ip)

        inventory_file_path = os.path.join(tmp_dir, "inventory.yml")
        with open(inventory_file_path, "w") as f:
            f.write(inventory_content)

        # Prepare log files
        start_time = datetime.datetime.now()
        timestamp = start_time.strftime("%Y%m%d_%H%M%S")
        ansible_log_file = os.path.join(tmp_dir, f"ansible_log_{{timestamp}}.log")
        api_log_file = os.path.join(tmp_dir, f"api_log_{{timestamp}}.log")

        # Test WinRM connection first
        print(f"🔍 Testing WinRM connection to {{target_ip}}...")
        ping_cmd = winrm_connection(inventory_file_path, "all")
        with open(ansible_log_file, "w") as logfile:
            ping_result = subprocess.run(ping_cmd, cwd=tmp_dir, stdout=logfile, stderr=subprocess.STDOUT, text=True)

        if ping_result.returncode != 0:
            end_time = datetime.datetime.now()
            api_log_entry = (
                f"[API LOG - OTP VERIFICATION]\n"
                f"Playbook: {{playbook_name}}\n"
                f"Target IP: {{target_ip}}\n"
                f"Expected OTP: {{expected_otp}}\n"
                f"Start Time: {{start_time}}\n"
                f"End Time: {{end_time}}\n"
                f"Status: FAILED (win_ping failed)\n"
                "------------------------------------------------------------\n"
            )
            with open(api_log_file, "a") as api_log:
                api_log.write(api_log_entry)

            result_dict['response'] = {
                "status": "failed",
                "message": f"WinRM connection to {{target_ip}} failed. Ensure WinRM is enabled.",
                "ansible_log": ansible_log_file,
                "api_log": api_log_file,
                "start_time": str(start_time),
                "end_time": str(end_time)
            }
            result_dict['status_code'] = 500
            return

        print(f"✅ WinRM connection successful")
        print(f"🔐 Starting OTP verification for {{target_ip}} with expected OTP: {{expected_otp}}")

        # Execute OTP verification playbook
        cmd = ["ansible-playbook", "-i", inventory_file_path, otp_playbook_path, "-v"]
        
        with open(ansible_log_file, "a") as logfile:
            logfile.write(f"\\n=== OTP VERIFICATION PLAYBOOK EXECUTION ===\\n")
            logfile.write(f"Expected OTP: {{expected_otp}}\\n")
            logfile.write(f"Target IP: {{target_ip}}\\n")
            logfile.write(f"Playbook: {{playbook_name}}\\n\\n")
            
            result = subprocess.run(cmd, cwd=tmp_dir, stdout=logfile, stderr=subprocess.STDOUT, text=True)

        end_time = datetime.datetime.now()

        # Clean up temporary files
        if os.path.exists(tmp_main_playbook_path):
            os.remove(tmp_main_playbook_path)
        if os.path.exists(otp_playbook_path):
            os.remove(otp_playbook_path)
        if os.path.exists(inventory_file_path):
            os.remove(inventory_file_path)

        # Determine execution status
        execution_status = "SUCCESS" if result.returncode == 0 else "FAILED"
        
        # Write API log
        api_log_entry = (
            f"[API LOG - OTP VERIFICATION]\n"
            f"Playbook: {{playbook_name}}\n"
            f"Source Path: {{playbook_src_path}}\n"
            f"Execution Folder: {{tmp_dir}}\n"
            f"Target IP: {{target_ip}}\n"
            f"Expected OTP: {{expected_otp}}\n"
            f"Start Time: {{start_time}}\n"
            f"End Time: {{end_time}}\n"
            f"Status: {{execution_status}}\n"
            f"Return Code: {{result.returncode}}\n"
            "------------------------------------------------------------\n"
        )
        with open(api_log_file, "a") as api_log:
            api_log.write(api_log_entry)

        # Determine failure reason for better user feedback
        failure_reason = "Unknown error"
        if result.returncode != 0:
            # Read the log to understand failure
            try:
                with open(ansible_log_file, 'r') as log_file:
                    log_content = log_file.read()
                    if "OTP file not found" in log_content:
                        failure_reason = f"OTP file not found on {{target_ip}}. Please create C:\\Users\\%USERNAME%\\Desktop\\otp.txt with the OTP: {{expected_otp}}"
                    elif "OTP verification failed" in log_content:
                        failure_reason = f"OTP mismatch. Please check the OTP in the desktop file matches: {{expected_otp}}"
                    elif "win_ping" in log_content:
                        failure_reason = f"Cannot connect to {{target_ip}}. Check WinRM configuration."
                    else:
                        failure_reason = "Playbook execution failed. Check ansible log for details."
            except:
                pass

        result_dict['response'] = {
            "status": "success" if result.returncode == 0 else "failed",
            "playbook": playbook_name,
            "target_ip": target_ip,
            "expected_otp": expected_otp,
            "execution_folder": tmp_dir,
            "ansible_log": ansible_log_file,
            "api_log": api_log_file,
            "start_time": str(start_time),
            "end_time": str(end_time),
            "return_code": result.returncode,
            "message": "Playbook executed successfully with OTP verification" if result.returncode == 0 else failure_reason
        }
        result_dict['status_code'] = 200 if result.returncode == 0 else 500

    except Exception as e:
        result_dict['response'] = {
            "status": "error",
            "message": f"Execution error: {{str(e)}}",
            "expected_otp": expected_otp
        }
        result_dict['status_code'] = 500

# API Endpoints

@app.route("/run-playbook-with-otp/<playbook_name>/<target_ip>/<otp>", methods=["POST"])
def run_playbook_with_otp(playbook_name, target_ip, otp):
    """
    Execute playbook with OTP verification
    URL: /run-playbook-with-otp/install-software.yml/192.168.1.100/123456
    """
    
    print(f"🚀 OTP Playbook Request:")
    print(f"   Playbook: {{playbook_name}}")
    print(f"   Target IP: {{target_ip}}")
    print(f"   Expected OTP: {{otp}}")
    
    # Validate OTP format
    if not otp.isdigit() or len(otp) != 6:
        return jsonify({
            "status": "error",
            "message": "Invalid OTP format. OTP must be 6 digits.",
            "provided_otp": otp
        }), 400
    
    result_dict = {}
    thread = threading.Thread(
        target=playbook_background_task_with_otp, 
        args=(playbook_name, target_ip, otp, result_dict)
    )
    thread.start()

    return jsonify({
        "status": "started",
        "message": f"Playbook execution started with OTP verification",
        "playbook": playbook_name,
        "target_ip": target_ip,
        "expected_otp": otp,
        "instructions": [
            f"1. On {{target_ip}}, create file: C:\\Users\\%USERNAME%\\Desktop\\otp.txt",
            f"2. Write this OTP in the file: {{otp}}",
            f"3. Save the file",
            f"4. Playbook will verify OTP and execute automatically",
            f"5. OTP file will be deleted after successful verification"
        ]
    }), 202

@app.route("/run-playbook-with-otp", methods=["POST"])
def run_playbook_with_otp_json():
    """
    Execute playbook with OTP verification (JSON payload)
    POST /run-playbook-with-otp
    {{
        "playbook_name": "install-software.yml",
        "target_ip": "192.168.1.100", 
        "otp": "123456"
    }}
    """
    try:
        data = request.json
        playbook_name = data.get('playbook_name')
        target_ip = data.get('target_ip')
        otp = data.get('otp')
        
        if not all([playbook_name, target_ip, otp]):
            return jsonify({
                "status": "error",
                "message": "Missing required fields: playbook_name, target_ip, otp"
            }), 400
        
        # Validate OTP
        if not str(otp).isdigit() or len(str(otp)) != 6:
            return jsonify({
                "status": "error",
                "message": "Invalid OTP format. OTP must be 6 digits.",
                "provided_otp": otp
            }), 400
        
        result_dict = {}
        thread = threading.Thread(
            target=playbook_background_task_with_otp, 
            args=(playbook_name, target_ip, str(otp), result_dict)
        )
        thread.start()

        return jsonify({
            "status": "started",
            "message": "Playbook execution started with OTP verification",
            "playbook": playbook_name,
            "target_ip": target_ip,
            "expected_otp": str(otp),
            "user_instructions": {{
                "step_1": f"On {{target_ip}}, open File Explorer",
                "step_2": f"Navigate to Desktop (C:\\Users\\%USERNAME%\\Desktop\\)",
                "step_3": f"Create a new text file named: otp.txt",
                "step_4": f"Write ONLY this number in the file: {{otp}}",
                "step_5": "Save the file",
                "step_6": "Playbook will automatically verify and execute",
                "note": "The OTP file will be deleted after successful verification"
            }}
        }), 202
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

# Chatbot Integration Endpoints

@app.route("/chatbot/generate-otp", methods=["POST"])
def chatbot_generate_otp():
    """
    Generate OTP for chatbot use
    POST /chatbot/generate-otp
    {{
        "playbook": "install-software.yml",
        "target_ip": "192.168.1.100"
    }}
    """
    try:
        data = request.json
        playbook = data.get('playbook') or data.get('playbook_name')
        target_ip = data.get('target_ip') or data.get('ip')
        
        if not all([playbook, target_ip]):
            return jsonify({
                "status": "error",
                "message": "Missing required fields: playbook, target_ip"
            }), 400
        
        # Generate 6-digit OTP
        generated_otp = generate_otp()
        
        return jsonify({
            "status": "success",
            "message": f"OTP generated for {{playbook}} execution on {{target_ip}}",
            "otp": generated_otp,
            "playbook": playbook,
            "target_ip": target_ip,
            "chatbot_instructions": f"Tell user: 'I've generated OTP {{generated_otp}} for you. Please create a file C:\\Users\\%USERNAME%\\Desktop\\otp.txt on {{target_ip}} and write {{generated_otp}} in it, then I'll execute the playbook.'",
            "user_steps": [
                f"1. Go to {{target_ip}} computer",
                f"2. Create file: C:\\Users\\%USERNAME%\\Desktop\\otp.txt", 
                f"3. Write in file: {{generated_otp}}",
                f"4. Save file",
                f"5. Tell chatbot: 'Execute with OTP {{generated_otp}}'"
            ],
            "execution_endpoint": f"/run-playbook-with-otp/{{playbook}}/{{target_ip}}/{{generated_otp}}"
        }), 200
        
    except Exception as e:
        return jsonify({
            "status": "error", 
            "message": str(e)
        }), 500

@app.route("/chatbot/execute-with-otp", methods=["POST"])
def chatbot_execute_with_otp():
    """
    Execute playbook with OTP (for chatbot use)
    POST /chatbot/execute-with-otp
    {{
        "playbook": "install-software.yml",
        "target_ip": "192.168.1.100",
        "otp": "123456"
    }}
    """
    try:
        data = request.json
        playbook = data.get('playbook') or data.get('playbook_name')
        target_ip = data.get('target_ip') or data.get('ip')
        otp = data.get('otp')
        
        if not all([playbook, target_ip, otp]):
            return jsonify({
                "status": "error",
                "message": "Missing required fields: playbook, target_ip, otp"
            }), 400
        
        # Forward to main execution endpoint
        return run_playbook_with_otp_json()
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

# Original endpoint (for backward compatibility)
@app.route("/run-playbook/<playbook_name>/<target_ip>", methods=["POST"])
def run_playbook_original(playbook_name, target_ip):
    """
    Original endpoint without OTP (kept for backward compatibility)
    WARNING: This bypasses OTP verification!
    """
    from original_execution import playbook_background_task  # Import your original function
    
    result_dict = {}
    thread = threading.Thread(target=playbook_background_task, args=(playbook_name, target_ip, result_dict))
    thread.start()

    return jsonify({
        "status": "started",
        "message": "Playbook running without OTP verification",
        "warning": "⚠️ This endpoint bypasses OTP security. Use /run-playbook-with-otp for secure execution."
    }), 202

# Utility endpoints

@app.route("/health", methods=["GET"])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "service": "File-based OTP Execution API",
        "timestamp": datetime.datetime.now().isoformat(),
        "otp_system": "file-based"
    }), 200

@app.route("/list-playbooks", methods=["GET"])
def list_playbooks():
    """List available playbooks"""
    try:
        if os.path.exists(PLAYBOOK_DIR):
            playbooks = [f for f in os.listdir(PLAYBOOK_DIR) 
                        if f.endswith('.yml') or f.endswith('.yaml')]
            return jsonify({
                "status": "success",
                "playbooks": sorted(playbooks),
                "total_count": len(playbooks)
            }), 200
        else:
            return jsonify({
                "status": "error",
                "message": f"Playbook directory not found: {{PLAYBOOK_DIR}}"
            }), 404
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@app.route("/test-otp-file/<target_ip>/<expected_otp>", methods=["GET"])
def test_otp_file(target_ip, expected_otp):
    """
    Test endpoint to check if OTP file exists and matches
    GET /test-otp-file/192.168.1.100/123456
    """
    try:
        # Create test inventory
        with open(INVENTORY_TEMPLATE_FILE, "r") as f:
            template = Template(f.read())
        inventory_content = template.render(target_ip=target_ip)
        
        test_inventory_path = f"/tmp/test_inventory_{{int(time.time())}}.yml"
        with open(test_inventory_path, "w") as f:
            f.write(inventory_content)
        
        # Test OTP file existence and content
        test_cmd = [
            "ansible", "-i", test_inventory_path, "all", "-m", "win_shell",
            "-a", f"if (Test-Path 'C:\\Users\\$env:USERNAME\\Desktop\\otp.txt') {{ Get-Content 'C:\\Users\\$env:USERNAME\\Desktop\\otp.txt' -Raw }} else {{ Write-Output 'FILE_NOT_FOUND' }}"
        ]
        
        result = subprocess.run(test_cmd, capture_output=True, text=True)
        
        # Cleanup test inventory
        if os.path.exists(test_inventory_path):
            os.remove(test_inventory_path)
        
        if result.returncode == 0:
            output = result.stdout.strip()
            if "FILE_NOT_FOUND" in output:
                return jsonify({
                    "status": "file_not_found",
                    "message": f"OTP file not found on {{target_ip}}",
                    "expected_otp": expected_otp,
                    "instructions": f"Create C:\\Users\\%USERNAME%\\Desktop\\otp.txt with content: {{expected_otp}}"
                }), 200
            else:
                # Extract actual OTP from ansible output
                lines = output.split('\\n')
                actual_otp = None
                for line in lines:
                    if line.strip() and not line.startswith(target_ip):
                        actual_otp = line.strip()
                        break
                
                if actual_otp == expected_otp:
                    return jsonify({
                        "status": "match",
                        "message": "OTP file exists and matches!",
                        "expected_otp": expected_otp,
                        "actual_otp": actual_otp
                    }), 200
                else:
                    return jsonify({
                        "status": "mismatch", 
                        "message": "OTP file exists but content doesn't match",
                        "expected_otp": expected_otp,
                        "actual_otp": actual_otp
                    }), 200
        else:
            return jsonify({
                "status": "error",
                "message": f"Failed to check OTP file on {{target_ip}}",
                "error": result.stderr
            }), 500
            
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

if __name__ == "__main__":
    print("🚀 Starting File-based OTP Execution API...")
    print("📁 OTP System: File-based (C:\\Users\\%USERNAME%\\Desktop\\otp.txt)")
    print("📝 Available endpoints:")
    print("   - POST /run-playbook-with-otp/<playbook>/<ip>/<otp> - Execute with OTP")
    print("   - POST /run-playbook-with-otp (JSON) - Execute with OTP (JSON payload)")
    print("   - POST /chatbot/generate-otp - Generate OTP for chatbot")
    print("   - POST /chatbot/execute-with-otp - Execute with OTP (chatbot)")
    print("   - GET  /test-otp-file/<ip>/<otp> - Test OTP file")
    print("   - POST /run-playbook/<playbook>/<ip> - Original (no OTP)")
    print("🔐 OTP File Location: C:\\Users\\%USERNAME%\\Desktop\\otp.txt")
    app.run(host="0.0.0.0", port=5000, debug=True)