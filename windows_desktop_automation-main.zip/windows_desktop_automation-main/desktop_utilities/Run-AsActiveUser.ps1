# Runs a command line in the currently active user's session (console or RDP)
param(
  [Parameter(Mandatory=$true)][string]$FilePath,
  [string]$Arguments = "",
  [string]$WorkingDirectory = "C:\Windows\System32"
)

Add-Type -TypeDefinition @"
using System;
using System.Text;
using System.Runtime.InteropServices;

public class WTS {
  [DllImport("wtsapi32.dll", SetLastError=true)]
  public static extern bool WTSEnumerateSessions(IntPtr hServer, int Reserved, int Version, out IntPtr ppSessionInfo, out int pCount);
  [DllImport("wtsapi32.dll")] public static extern void WTSFreeMemory(IntPtr pMemory);
  [DllImport("wtsapi32.dll", SetLastError=true)] public static extern bool WTSQueryUserToken(int sessionId, out IntPtr Token);
  [DllImport("kernel32.dll")] public static extern IntPtr WTSGetActiveConsoleSessionId();

  [StructLayout(LayoutKind.Sequential)]
  public struct WTS_SESSION_INFO {
    public int SessionId; public string pWinStationName; public int State;
  }
}

public class AdvApi {
  [DllImport("advapi32.dll", SetLastError=true)]
  public static extern bool DuplicateTokenEx(
      IntPtr hExistingToken, uint dwDesiredAccess, IntPtr lpTokenAttributes,
      int ImpersonationLevel, int TokenType, out IntPtr phNewToken);

  [DllImport("userenv.dll", SetLastError=true)]
  public static extern bool CreateEnvironmentBlock(out IntPtr lpEnvironment, IntPtr hToken, bool bInherit);

  [DllImport("userenv.dll", SetLastError=true)]
  public static extern bool DestroyEnvironmentBlock(IntPtr lpEnvironment);

  [DllImport("advapi32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
  public static extern bool CreateProcessAsUser(
      IntPtr hToken, string lpApplicationName, string lpCommandLine,
      IntPtr lpProcessAttributes, IntPtr lpThreadAttributes, bool bInheritHandles,
      uint dwCreationFlags, IntPtr lpEnvironment, string lpCurrentDirectory,
      ref STARTUPINFO lpStartupInfo, out PROCESS_INFORMATION lpProcessInformation);

  [DllImport("kernel32.dll", SetLastError=true)]
  public static extern bool CloseHandle(IntPtr hObject);

  public const int SecurityImpersonation = 2;
  public const int TokenPrimary = 1;
  public const uint GENERIC_ALL = 0x10000000;
  public const uint CREATE_UNICODE_ENVIRONMENT = 0x00000400;

  [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
  public struct STARTUPINFO {
    public int cb; public string lpReserved; public string lpDesktop; public string lpTitle;
    public int dwX; public int dwY; public int dwXSize; public int dwYSize;
    public int dwXCountChars; public int dwYCountChars; public int dwFillAttribute;
    public int dwFlags; public short wShowWindow; public short cbReserved2; public IntPtr lpReserved2; public IntPtr hStdInput; public IntPtr hStdOutput; public IntPtr hStdError;
  }
  [StructLayout(LayoutKind.Sequential)]
  public struct PROCESS_INFORMATION { public IntPtr hProcess; public IntPtr hThread; public int dwProcessId; public int dwThreadId; }
}
"@

function Get-ActiveSessionId {
  # Prefer the console session if someone is at the keyboard
  $sid = [WTS]::WTSGetActiveConsoleSessionId()
  if ($sid -ne [IntPtr]::Zero) { return [int]$sid }

  # Fallback: find a user session where explorer.exe is running
  $explorer = Get-Process explorer -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($explorer) { return $explorer.SessionId }

  throw "No active user session found."
}

$sessionId = Get-ActiveSessionId
[IntPtr]$userTok = [IntPtr]::Zero
if (-not [WTS]::WTSQueryUserToken($sessionId, [ref]$userTok)) {
  throw "WTSQueryUserToken failed: $([ComponentModel.Win32Exception]::new([Runtime.InteropServices.Marshal]::GetLastWin32Error()).Message)"
}

[IntPtr]$primaryTok = [IntPtr]::Zero
if (-not [AdvApi]::DuplicateTokenEx($userTok, [AdvApi]::GENERIC_ALL, [IntPtr]::Zero, [AdvApi]::SecurityImpersonation, [AdvApi]::TokenPrimary, [ref]$primaryTok)) {
  [AdvApi]::CloseHandle($userTok) | Out-Null
  throw "DuplicateTokenEx failed: $([ComponentModel.Win32Exception]::new([Runtime.InteropServices.Marshal]::GetLastWin32Error()).Message)"
}

[IntPtr]$env = [IntPtr]::Zero
if (-not [AdvApi]::CreateEnvironmentBlock([ref]$env, $primaryTok, $true)) {
  [AdvApi]::CloseHandle($primaryTok) | Out-Null
  [AdvApi]::CloseHandle($userTok) | Out-Null
  throw "CreateEnvironmentBlock failed: $([ComponentModel.Win32Exception]::new([Runtime.InteropServices.Marshal]::GetLastWin32Error()).Message)"
}

$si = New-Object AdvApi+STARTUPINFO
$si.cb = [Runtime.InteropServices.Marshal]::SizeOf([type]AdvApi+STARTUPINFO)
$si.lpDesktop = "winsta0\default"  # ensure it appears on the user's desktop

$pi = New-Object AdvApi+PROCESS_INFORMATION
$cmdLine = '"' + $FilePath + '"' + ( $Arguments -ne "" ? (' ' + $Arguments) : "" )

$ok = [AdvApi]::CreateProcessAsUser(
  $primaryTok, $null, $cmdLine, [IntPtr]::Zero, [IntPtr]::Zero, $false,
  [AdvApi]::CREATE_UNICODE_ENVIRONMENT, $env, $WorkingDirectory, [ref]$si, [ref]$pi)

# cleanup
[AdvApi]::DestroyEnvironmentBlock($env) | Out-Null
if ($pi.hThread -ne [IntPtr]::Zero) { [AdvApi]::CloseHandle($pi.hThread) | Out-Null }
if ($pi.hProcess -ne [IntPtr]::Zero) { [AdvApi]::CloseHandle($pi.hProcess) | Out-Null }
[AdvApi]::CloseHandle($primaryTok) | Out-Null
[AdvApi]::CloseHandle($userTok) | Out-Null

if (-not $ok) {
  throw "CreateProcessAsUser failed: $([ComponentModel.Win32Exception]::new([Runtime.InteropServices.Marshal]::GetLastWin32Error()).Message)"
}
